package vn.edu.huflit.doan_ltmnc.client;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.InputStreamReader;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import java.net.Socket;
import java.nio.file.Files;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.function.Consumer;

import vn.edu.huflit.doan_ltmnc.CryptoUtils;

public class ClientCore {

   public static void send(String rawMessage, String domain, Consumer<String> callback) {
    new Thread(() -> {
        try (Socket socket = new Socket("localhost", 8887)) {
            DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
            BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));

            // Load private/public key
            PrivateKey privateKey = CryptoUtils.loadPrivateKey("private_key.der");
            byte[] pubKeyBytes = Files.readAllBytes(new File("public_key.der").toPath());

            // Ký raw message
            byte[] signature = CryptoUtils.signMessage(rawMessage, privateKey);
            String signatureBase64 = Base64.getEncoder().encodeToString(signature);

            // Tạo AES key và IV
            byte[] aesKeyBytes = new byte[16];
            byte[] ivBytes = new byte[16];
            SecureRandom random = new SecureRandom();
            random.nextBytes(aesKeyBytes);
            random.nextBytes(ivBytes);

            SecretKey aesKey = new SecretKeySpec(aesKeyBytes, "AES");
            IvParameterSpec iv = new IvParameterSpec(ivBytes);

            // Mã hóa public key bằng AES
            byte[] encryptedPubKey = CryptoUtils.encryptAES(pubKeyBytes, aesKey, iv);
                    
            // Gửi dữ liệu
            dos.writeUTF(rawMessage);
            dos.writeUTF(signatureBase64);
            dos.writeUTF(domain);
            dos.writeInt(encryptedPubKey.length);
            dos.write(encryptedPubKey);
            
            PublicKey serverPublicKey = CryptoUtils.loadPublicKey("server_public.der");

           // Mã hóa AES key & IV bằng khóa RSA của server
            byte[] encryptedAESKey = CryptoUtils.encryptRSA(aesKeyBytes, serverPublicKey);
            byte[] encryptedIV = CryptoUtils.encryptRSA(ivBytes, serverPublicKey);
            

             // Gửi từng phần đến server
            dos.write(encryptedAESKey);
            dos.write(encryptedIV);

            dos.flush();

            // Nhận phản hồi từ server
            String line;
            while ((line = reader.readLine()) != null) {
                callback.accept(line);
                if (line.contains("SCAN_DONE") || line.contains("VERIFICATION_FAILED")) break;
            }

        } catch (Exception e) {
            callback.accept("❌ Error: " + e.getMessage());
        }
        }).start();
    }
}