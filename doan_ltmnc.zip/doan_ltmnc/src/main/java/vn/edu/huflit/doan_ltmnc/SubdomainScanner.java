package vn.edu.huflit.doan_ltmnc;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URL;

public class SubdomainScanner {

    public static int scan(String domain, BufferedWriter writer) throws IOException {
        int count = 0;
        int maxFound = 5;
        File wordlist = new File("src/main/resources/subdomains-top1million-110000.txt");

        if (!wordlist.exists()) {
            writer.write(" Wordlist not found.\n");
            writer.flush();
            return 0;
        }

         try (BufferedReader reader = new BufferedReader(new FileReader(wordlist))) {
            String sub;
            while ((sub = reader.readLine()) != null) {
                String fullDomain = sub + "." + domain;
                String url = "http://" + fullDomain;

                if (isReachable(url)) {
                    String ip = resolveIP(fullDomain);
                    writer.write(" Found: " + url + " [IP: " + ip + "]\n");
                    writer.flush();
                    count++;
                    if (count >= maxFound) break;
                }
                
                
            }
        }

        writer.write("\n Scan completed. " + count + " subdomains found.\n");
        writer.write(" SCAN_DONE\n"); // dùng để GUI nhận biết
        writer.flush();
        return count;
    }

    private static boolean isReachable(String urlStr) {
        try {
            URL url = new URL(urlStr);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(1000);
            conn.setReadTimeout(1000);
            conn.setRequestMethod("HEAD");
            int code = conn.getResponseCode();
            return code >= 200 && code < 400;
        } catch (IOException e) {
            return false;
        }
    }
    private static String resolveIP(String hostname) {
        try {
            InetAddress address = InetAddress.getByName(hostname);
            return address.getHostAddress();
        } catch (Exception e) {
            return "Unknown";
        }
    }
}
