package vn.edu.huflit.doan_ltmnc;

public class ClientCounter {
    private static int counter = 0;

    public synchronized static int getNext() {
        return ++counter;
    }
}
