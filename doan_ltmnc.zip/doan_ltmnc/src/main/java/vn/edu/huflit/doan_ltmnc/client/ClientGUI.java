package vn.edu.huflit.doan_ltmnc.client;

import com.formdev.flatlaf.FlatDarkLaf;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfWriter;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.io.*;
import java.net.Socket;
import java.nio.file.Files;
import java.security.PrivateKey;
import java.security.SecureRandom;
import java.util.*;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.util.List;
import java.util.Arrays;


import vn.edu.huflit.doan_ltmnc.CryptoUtils;

public class ClientGUI extends JFrame {

    private JTextField messageField, domainField;
    private JTextArea responseArea;
    private JButton sendButton, saveButton, historyButton, exitButton;
    private StringBuilder latestScanResult = new StringBuilder();
    private final Set<String> domainHistory = new LinkedHashSet<>();

    public ClientGUI() {
        FlatDarkLaf.setup();
        setTitle("Subdomain Scanner");
        setSize(850, 620);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Top panel: Message and Domain fields
        JPanel topPanel = new JPanel();
        topPanel.setLayout(new BoxLayout(topPanel, BoxLayout.Y_AXIS));
        topPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel messagePanel = new JPanel(new BorderLayout(8, 8));
        JLabel messageLabel = new JLabel("Message:");
        messageField = new JTextField("Hello from client");
        messagePanel.add(messageLabel, BorderLayout.WEST);
        messagePanel.add(messageField, BorderLayout.CENTER);

        JPanel domainPanel = new JPanel(new BorderLayout(8, 8));
        JLabel domainLabel = new JLabel("Domain:");
        domainField = new JTextField("huflit.edu.vn");
        domainPanel.add(domainLabel, BorderLayout.WEST);
        domainPanel.add(domainField, BorderLayout.CENTER);

        topPanel.add(messagePanel);
        topPanel.add(Box.createVerticalStrut(10));
        topPanel.add(domainPanel);

        add(topPanel, BorderLayout.NORTH);

        // Center area: response from server
        responseArea = new JTextArea();
        responseArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(responseArea);
        add(scrollPane, BorderLayout.CENTER);

        // Bottom: control buttons
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 10));
        sendButton = new JButton("Send");
        saveButton = new JButton("Save");
        historyButton = new JButton("History");
        exitButton = new JButton("❌ Exit");

        bottomPanel.add(sendButton);
        bottomPanel.add(saveButton);
        bottomPanel.add(historyButton);
        bottomPanel.add(exitButton);
        add(bottomPanel, BorderLayout.SOUTH);

        sendButton.addActionListener(e -> sendRequest());
        saveButton.addActionListener(e -> saveResult());
        historyButton.addActionListener(e -> showHistory());
        exitButton.addActionListener(e -> System.exit(0));

        setupAutoComplete(domainField);
    }

    private void sendRequest() {
        sendButton.setEnabled(false);
        latestScanResult.setLength(0);

        String domain = domainField.getText().trim();
        String message = messageField.getText().trim();

        if (domain.isEmpty() || message.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter both domain and message.", "Warning", JOptionPane.WARNING_MESSAGE);
            sendButton.setEnabled(true);
            return;
        }

        responseArea.append("Sending request for domain: " + domain + "\n");
        domainHistory.add(domain);

        new Thread(() -> {
            try (Socket socket = new Socket("localhost", 8887)) {
                DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
                BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));

                PrivateKey privateKey = CryptoUtils.loadPrivateKey("private_key.der");
                byte[] pubKeyBytes = Files.readAllBytes(new File("public_key.der").toPath());

                byte[] signature = CryptoUtils.signMessage(message, privateKey);
                String signatureBase64 = Base64.getEncoder().encodeToString(signature);
                
                // ✅ Hiển thị Base64 signature gọn gàng trên GUI
                responseArea.append("BASE64 Signature:\n");
                for (int i = 0; i < signatureBase64.length(); i += 64) {
                int end = Math.min(i + 64, signatureBase64.length());
                responseArea.append("  " + signatureBase64.substring(i, end) + "\n");
                }

                byte[] aesKeyBytes = new byte[16];
                byte[] ivBytes = new byte[16];
                new SecureRandom().nextBytes(aesKeyBytes);
                new SecureRandom().nextBytes(ivBytes);

                SecretKey aesKey = new SecretKeySpec(aesKeyBytes, "AES");
                IvParameterSpec iv = new IvParameterSpec(ivBytes);
                byte[] encryptedPubKey = CryptoUtils.encryptAES(pubKeyBytes, aesKey, iv);

                dos.writeUTF(message);
                dos.writeUTF(signatureBase64);
                dos.writeUTF(domain);
                dos.writeInt(encryptedPubKey.length);
                dos.write(encryptedPubKey);
                dos.write(aesKeyBytes);
                dos.write(ivBytes);
                dos.flush();

                String line;
                while ((line = reader.readLine()) != null) {
                     responseArea.append("[Server] " + line + "\n");
                     latestScanResult.append(line).append("\n");
                    if (line.contains("SCAN_DONE") || line.contains("VERIFICATION_FAILED")) break;
                }

            } catch (Exception ex) {
                ex.printStackTrace();
                responseArea.append("❌ Error: " + ex.getMessage() + "\n");
            } finally {
                sendButton.setEnabled(true);
            }
        }).start();
    }

    private void saveResult() {
        if (latestScanResult.length() == 0) {
            JOptionPane.showMessageDialog(this, "Nothing to save.");
            return;
        }

        String[] options = {"TXT", "PDF"};
        int choice = JOptionPane.showOptionDialog(this, "Save as:", "Save Result",
                JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[0]);

        JFileChooser chooser = new JFileChooser();
        if (chooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            File file = chooser.getSelectedFile();
            try {
                if (choice == 1) { // PDF
                    Document document = new Document();
                    PdfWriter.getInstance(document, new FileOutputStream(file.getAbsolutePath() + ".pdf"));
                    document.open();
                    document.add(new Paragraph(latestScanResult.toString()));
                    document.close();
                } else { // TXT
                    BufferedWriter writer = new BufferedWriter(new FileWriter(file.getAbsolutePath() + ".txt"));
                    writer.write(latestScanResult.toString());
                    writer.close();
                }
                JOptionPane.showMessageDialog(this, "Result saved.");
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Save failed: " + e.getMessage());
            }
        }
    }

    private void showHistory() {
        if (domainHistory.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No history yet.");
            return;
        }

        JList<String> list = new JList<>(domainHistory.toArray(new String[0]));
        JScrollPane pane = new JScrollPane(list);
        JOptionPane.showMessageDialog(this, pane, "History", JOptionPane.PLAIN_MESSAGE);
    }

    private void setupAutoComplete(JTextField field) {
        List<String> suggestions = Arrays.asList(
                "huflit.edu.vn", "google.com", "facebook.com", "youtube.com", "github.com"
        );

        JPopupMenu popup = new JPopupMenu();
        JList<String> suggestionList = new JList<>();
        popup.setFocusable(false);
        JScrollPane scroll = new JScrollPane(suggestionList);
        scroll.setBorder(null);
        popup.add(scroll);

        suggestionList.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                String selected = suggestionList.getSelectedValue();
                if (selected != null) {
                    field.setText(selected);
                    popup.setVisible(false);
                }
            }
        });

        field.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { showSuggestions(); }
            public void removeUpdate(DocumentEvent e) { showSuggestions(); }
            public void changedUpdate(DocumentEvent e) {}

            private void showSuggestions() {
                SwingUtilities.invokeLater(() -> {
                    String text = field.getText();
                    if (text.isEmpty()) {
                        popup.setVisible(false);
                        return;
                    }

                    List<String> filtered = suggestions.stream()
                            .filter(s -> s.startsWith(text))
                            .toList();

                    if (filtered.isEmpty()) {
                        popup.setVisible(false);
                        return;
                    }

                    suggestionList.setListData(filtered.toArray(new String[0]));
                    suggestionList.setSelectedIndex(0);
                    popup.show(field, 0, field.getHeight());
                    field.requestFocusInWindow();
                });
            }
        });
    }

    
}
