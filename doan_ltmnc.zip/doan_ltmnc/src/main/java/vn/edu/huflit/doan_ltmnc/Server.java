package vn.edu.huflit.doan_ltmnc;

import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.net.ServerSocket;
import java.net.Socket;
import java.security.PublicKey;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Base64;

public class Server {
    public static void main(String[] args) throws IOException {
        ServerSocket serverSocket = new ServerSocket(8887);
        System.out.println("Server is running on port 8887...");

        while (true) {
            Socket socket = serverSocket.accept();
            int clientId = ClientCounter.getNext();
            String clientIP = socket.getInetAddress().getHostAddress();
            System.out.printf(">>>>>>>>>>>Client %d connected from IP: %s\n", clientId, clientIP);

            // Log kết nối vào file
            try (FileWriter log = new FileWriter("connection_log.txt", true)) {
                log.write(String.format("Client %d | IP: %s | Time: %s\n",
                    clientId,
                    clientIP,
                    LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))
                ));
            }

            new Thread(() -> {
                try (
                    DataInputStream dis = new DataInputStream(socket.getInputStream());
                    BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()))
                ) {
                    String message = dis.readUTF();
                    String signatureBase64 = dis.readUTF();
                    String domain = dis.readUTF();

                    // Kiểm tra domain trước khi tiếp tục
                    if (!domain.matches("^[a-zA-Z0-9.-]+\\.(com|edu\\.vn)$")) {
                        System.out.println("VERIFICATION_FAILED");
                        bw.write("VERIFICATION_FAILED\n");
                        bw.flush();
                        return;
                    }

                    int encryptedLen = dis.readInt();
                    byte[] encryptedPubKey = dis.readNBytes(encryptedLen);
                    byte[] aesKeyBytes = dis.readNBytes(16);
                    byte[] ivBytes = dis.readNBytes(16);

                    // Giải mã public key
                    SecretKey aesKey = new SecretKeySpec(aesKeyBytes, "AES");
                    IvParameterSpec iv = new IvParameterSpec(ivBytes);
                    byte[] pubKeyBytes = CryptoUtils.decryptAES(encryptedPubKey, aesKey, iv);
                    PublicKey pubKey = CryptoUtils.getPublicKeyFromBytes(pubKeyBytes);

                    // Ghi log AES key/IV
                    String encodedKey = Base64.getEncoder().encodeToString(aesKeyBytes);
                    String encodedIV = Base64.getEncoder().encodeToString(ivBytes);
                    String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));

                    System.out.println("\n=== DECRYPTED DATA ===");
                    System.out.println("Time     : " + timestamp);
                    System.out.println("AES Key  : " + encodedKey);
                    System.out.println("AES IV   : " + encodedIV);
                    System.out.println("==========================");

                    try (FileWriter fw = new FileWriter("db.txt", true)) {
                        fw.write("Timestamp: " + timestamp + "\n");
                        fw.write("Key     : " + encodedKey + "\n");
                        fw.write("IV      : " + encodedIV + "\n\n");
                    }

                    // ✅ Xác thực chữ ký
                    boolean valid = CryptoUtils.verifySignature(
                        message,
                        Base64.getDecoder().decode(signatureBase64),
                        pubKey
                    );

                    if (!valid) {
                        bw.write("VERIFICATION_FAILED\n");
                        bw.flush();
                        return;
                    }

                    // ✅ Nếu xác thực thành công → bắt đầu scan
                    bw.write("Signature verified successfully.\n");
                    bw.flush();

                    int count = SubdomainScanner.scan(domain, bw);

                    bw.write("Tổng subdomain tìm thấy: " + count + "\n");
                    bw.write("SCAN_DONE\n");
                    bw.flush();

                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    try {
                        socket.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }).start();
        }
    }
}
