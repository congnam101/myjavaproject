/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Server;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author congnammm
 */
public class Inter {
    private static PrintWriter send;
    private static Scanner receive;
public static void main (String [] args) throws IOException, InterruptedException{
    ServerSocket ss = new ServerSocket(12345);
    Socket s =new Socket();
    System.out.println("Server dang cho.....");
    int n=0;
Socket[] soc=new Socket[10];

int[]num =new int[10];

while(n<=3){
s=ss.accept();
soc[n]=s;
Core core = new Core(soc[n]);

num[n]=core.data;
System.out.println (n+" - "+soc[n].getInetAddress()+" - "+soc[n].getPort()+" - "+core.data);
n++;
}
Random ran =new Random();
int go =ran.nextInt(1, 3);
    System.out.println("KQ: "+num[go]);
    System.out.println("CMB: "+soc[go].getPort());
    
    send =new PrintWriter (soc[go].getOutputStream(),true);
    receive = new Scanner (soc[go].getInputStream());
    
    for (int i = 0; i < n; i++) {
    send = new PrintWriter(soc[i].getOutputStream(), true);
    if (i == go) {
        send.println("chuc mung ban da chien thang");
String winnerInfo = "Client IP: " + soc[go].getInetAddress() + "Port: " + soc[go].getPort();
showImage("Chuc mung " + winnerInfo, System.getProperty("user.dir") + "/hinhanh/winner.jpg");
    } else {
        send.println("Chuc ban may man lan sau");
       
    }
}
}
public static void showImage(String title, String imagePath) {
    javax.swing.JFrame frame = new javax.swing.JFrame(title);
    javax.swing.ImageIcon icon = new javax.swing.ImageIcon(imagePath);
    javax.swing.JLabel label = new javax.swing.JLabel(icon);
    frame.add(label);
    frame.setDefaultCloseOperation(javax.swing.JFrame.EXIT_ON_CLOSE);
    frame.pack();
    frame.setVisible(true);
    frame.setSize(800, 600);
}




    
}
