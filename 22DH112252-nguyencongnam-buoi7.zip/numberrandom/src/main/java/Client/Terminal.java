/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package Client;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

/**
 *
 * @author congnammm
 */
public class Terminal {

    public static void main(String[] args) throws IOException {
        Socket socket = new Socket ("127.0.0.1", 12345);
        PrintWriter send = new PrintWriter (socket.getOutputStream(), true);
        Scanner receive =new Scanner (socket.getInputStream());
        
        System.out.println("server: =>> so cua ban la:"+ receive.nextLine());
        try {
            System.out.println("server: =>> "+ receive.nextLine());
        } catch (Exception e) {
        }
        
    }
}
