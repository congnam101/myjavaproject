package com.huflit.server;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class Utils {

    // Hàm chuyển chuỗi sang MD5
    public static String md5(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] messageDigest = md.digest(input.getBytes());

            StringBuilder sb = new StringBuilder();
            for (byte b : messageDigest) {
                sb.append(String.format("%02x", b & 0xff));
            }
            return sb.toString();

        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }

    // Hàm trả về cung hoàng đạo theo ngày và tháng
    public static String getZodiac(int day, int month) {
        switch (month) {
            case 1:
                return (day < 20) ? "Ma Kết" : "Bảo Bình";
            case 2:
                return (day < 19) ? "Bảo Bình" : "Song Ngư";
            case 3:
                return (day < 21) ? "Song Ngư" : "Bạch Dương";
            case 4:
                return (day < 20) ? "Bạch Dương" : "Kim Ngưu";
            case 5:
                return (day < 21) ? "Kim Ngưu" : "Song Tử";
            case 6:
                return (day < 21) ? "Song Tử" : "Cự Giải";
            case 7:
                return (day < 23) ? "Cự Giải" : "Sư Tử";
            case 8:
                return (day < 23) ? "Sư Tử" : "Xử Nữ";
            case 9:
                return (day < 23) ? "Xử Nữ" : "Thiên Bình";
            case 10:
                return (day < 23) ? "Thiên Bình" : "Bọ Cạp";
            case 11:
                return (day < 22) ? "Bọ Cạp" : "Nhân Mã";
            case 12:
                return (day < 22) ? "Nhân Mã" : "Ma Kết";
            default:
                return "Không xác định";
        }
    }
}
