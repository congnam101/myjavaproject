package com.huflit.guiemailtudong;

import jakarta.mail.*;
import jakarta.mail.internet.*;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class Guiemailtudong {

    // email và mật khẩu ứng dụng
    private static final String SENDER_EMAIL = "congnam290918@gmail.com";
    private static final String SENDER_PASSWORD = "ofja sliy mzqy xhbp";
    private static final String EXCEL_FILE_PATH = "emails.xlsx"; 

    public static void main(String[] args) {
        try (FileInputStream fis = new FileInputStream(EXCEL_FILE_PATH);
             Workbook workbook = new XSSFWorkbook(fis)) {

            Sheet sheet = workbook.getSheetAt(0);

            // Cấu hình SMTP
            Properties props = new Properties();
            props.put("mail.smtp.auth", "true");
            props.put("mail.smtp.starttls.enable", "true");
            props.put("mail.smtp.host", "smtp.gmail.com");
            props.put("mail.smtp.port", "587");

            Session session = Session.getInstance(props, new Authenticator() {
                @Override
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(SENDER_EMAIL, SENDER_PASSWORD);
                }
            });

            // Lặp qua các dòng trong Excel
            for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                Row row = sheet.getRow(i);
                if (row == null) continue;

                String email = row.getCell(0).getStringCellValue();
                String name = row.getCell(1).getStringCellValue();

                // Gửi email
                sendEmail(session, email, name);
            }

        } catch (IOException e) {
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void sendEmail(Session session, String recipient, String name) {
        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(SENDER_EMAIL));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recipient));
            message.setSubject("Thư tự động gửi đến " + name);

            String content = "Xin chào " + name + ",\n\n"
                    + "Đây là thư gửi tự động bằng Java.\n\n"
                    + "Trân trọng,\nĐội phát triển.";

            message.setText(content);

            Transport.send(message);
            System.out.println("da gui email cho: " + recipient);

        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }
}
