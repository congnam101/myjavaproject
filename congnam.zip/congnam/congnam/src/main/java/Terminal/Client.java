/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Terminal;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

/**
 *
 * @author congnammm
 */
public class Client 
{
    Socket server;
    Scanner in;
    Scanner key;
    PrintWriter out;
    
    
    
    public Client (String dest, int port){
        try {
            server = new Socket(dest,port);
            
            key = new Scanner(System.in);
            String s =key.nextLine();
            
            
            out = new PrintWriter(server.getOutputStream());
            out.println(s);
            
            
            
            in=new Scanner(server.getInputStream());
            String receiveMes = in.nextLine();
            System.out.println("Ket qua tu server: "+receiveMes);
            
        } catch (IOException e) {
        }
    }
    public static void main(String[] args){
     Client client = new Client("localhost", 8888);
    }
}
