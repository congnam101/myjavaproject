/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package service;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.time.LocalDateTime;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author congnammm
 */
public class server {
    public static String thoigian(){
        LocalDateTime gioHienTai = LocalDateTime.now();
        String s=gioHienTai.toString();
        return s;
    }
    public static int ngaunhien(){
    Random ran = new Random();
    int s=ran.nextInt(0,99);
    return s;
    }
    

    public static void main(String[] args) {
        Scanner in;
    PrintWriter out;
        try {
            ServerSocket server = new ServerSocket(8888);   
                Socket client = server.accept();
                
            in= new Scanner(client.getInputStream());
            String receiveMes = in.nextLine();
            System.out.println("Client: "+receiveMes);
            switch (receiveMes) {
                case "t" ->
                {
                out = new PrintWriter(client.getOutputStream(),true);
                out.println(thoigian());
                }
                case "s" ->
                {
                out = new PrintWriter(client.getOutputStream(),true);
                out.print(""+ngaunhien());
                }
                    
                default -> System.out.print("loi");
                   
            }
            
            
        } catch (IOException e) {
        }
    }
}
