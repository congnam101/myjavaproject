package com.huflit.server;
import java.io.*;
import java.net.*;
import java.security.*;
import java.util.Scanner;

public class Client {
    private static final String SERVER_IP = "localhost";
    private static final int SERVER_PORT = 12345;

    public static void main(String[] args) {
        try (
            Socket socket = new Socket(SERVER_IP, SERVER_PORT);
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream(), "UTF-8"));
            PrintWriter out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), "UTF-8"), true);
            Scanner scanner = new Scanner(System.in)
        ) {
            String response;

            while ((response = in.readLine()) != null) {
                System.out.println(response);

                if (response.equals("Username:")) {
                    String username = scanner.nextLine();
                    out.println(username);
                } else if (response.equals("Password (MD5):")) {
                    String password = scanner.nextLine();
                    out.println(md5(password));
                } else if (response.startsWith("Captcha:")) {
                    // Nhận câu hỏi captcha
                    String captchaAnswer = scanner.nextLine();
                    out.println(captchaAnswer);
                } else if (response.contains("Captcha sai")) {
                    break;
                } else if (response.contains("Login successful") || response.contains("Tài khoản hoặc mật khẩu không đúng")) {
                    continue;
                } else if (response.startsWith("---")) {
                    handleMenu(in, out, scanner, response.contains("Admin"));
                }
            }

        } catch (IOException e) {
            System.err.println("Lỗi kết nối đến server: " + e.getMessage());
        }
    }

    private static void handleMenu(BufferedReader in, PrintWriter out, Scanner scanner, boolean isAdmin) throws IOException {
        String line;
        while ((line = in.readLine()) != null) {
            System.out.println(line);

            if (line.startsWith("Chọn chức năng")) {
                String choice = scanner.nextLine();
                out.println(choice);
            } else if (line.contains("Tên user mới:") || line.contains("Tên user cần đổi:") || line.contains("Mật khẩu mới:") || line.contains("Nhập ngày sinh") || line.contains("Nhập tháng sinh")) {
                String input = scanner.nextLine();
                out.println(input);
            } else if (line.contains("Bạn có muốn thử lại?")) {
                String input = scanner.nextLine();
                out.println(input);
                if (!input.equalsIgnoreCase("y")) return;
            } else if (line.contains("Thoát") || line.contains("Đã đổi mật khẩu") || line.contains("Tạo user thành công") || line.contains("Không tìm thấy user") || line.contains("cung hoàng đạo của bạn là")) {
                continue;
            } else if (line.trim().isEmpty()) {
                break;
            }
        }
    }

    private static String md5(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] hashBytes = md.digest(input.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte b : hashBytes) {
                sb.append(String.format("%02x", b & 0xff));
            }
            return sb.toString();
        } catch (Exception e) {
            return null;
        }
    }
}
