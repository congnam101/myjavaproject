package com.huflit.server;

import java.io.*;
import java.net.*;
import java.util.*;

public class Server {
    private static final int PORT = 12345;
    private static final String ACCOUNT_FILE = "accounts.txt";
    private static HashMap<String, String> accounts = new HashMap<>();

    public static void main(String[] args) throws IOException {
        loadAccounts();
        ServerSocket serverSocket = new ServerSocket(PORT);
        System.out.println("Server started on port " + PORT);
        while (true) {
            Socket client = serverSocket.accept();
            new ClientHandler(client).start();
        }
    }

    private static void loadAccounts() {
        File file = new File(ACCOUNT_FILE);
        if (!file.exists()) {
            accounts.put("admin", Utils.md5("admin"));
            saveAccounts();
        } else {
            try (BufferedReader br = new BufferedReader(new FileReader(file))) {
                String line;
                while ((line = br.readLine()) != null) {
                    String[] parts = line.split(":");
                    if (parts.length == 2)
                        accounts.put(parts[0], parts[1]);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static void saveAccounts() {
        try (PrintWriter pw = new PrintWriter(new FileWriter(ACCOUNT_FILE))) {
            for (Map.Entry<String, String> entry : accounts.entrySet()) {
                pw.println(entry.getKey() + ":" + entry.getValue());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static class ClientHandler extends Thread {
        private Socket socket;

        ClientHandler(Socket socket) {
            this.socket = socket;
        }

        public void run() {
            try (BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                 PrintWriter out = new PrintWriter(socket.getOutputStream(), true)) {

                out.println("Welcome! Please login.");
                String username, password;

                while (true) {
                    out.println("Username:");
                    username = in.readLine();
                    out.println("Password (MD5):");
                    password = in.readLine();

                    // Gửi captcha
                    String[] captcha = generateCaptcha();
                    out.println(captcha[0]);
                    String captchaAnswer = in.readLine();

                    if (!captchaAnswer.equals(captcha[1])) {
                        out.println("Captcha sai. Đóng kết nối.");
                        return;
                    }

                    if (accounts.containsKey(username) && accounts.get(username).equals(password)) {
                        out.println("Login successful as " + username);
                        break;
                    } else {
                        out.println("Tài khoản hoặc mật khẩu không đúng. Vui lòng thử lại.");
                    }
                }

                if (username.equals("admin")) {
                    handleAdmin(in, out);
                } else {
                    handleUser(username, in, out);
                }

            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        private String[] generateCaptcha() {
            Random rand = new Random();
            int a = rand.nextInt(10);
            int b = rand.nextInt(10);
            String question = "Captcha: " + a + " + " + b + " = ?";
            String answer = String.valueOf(a + b);
            return new String[]{question, answer};
        }

        private void handleAdmin(BufferedReader in, PrintWriter out) throws IOException {
            while (true) {
                out.println("\n--- Admin Menu ---");
                out.println("1. Tạo user");
                out.println("2. Đổi mật khẩu của chính mình");
                out.println("3. Đổi mật khẩu của user khác");
                out.println("4. Xem cung hoàng đạo");
                out.println("5. Thoát");
                out.println("Chọn chức năng (1-5):");

                String choice = in.readLine();
                switch (choice) {
                    case "1":
                        out.println("Tên user mới:");
                        String newUser = in.readLine();
                        out.println("Mật khẩu mới:");
                        String newPass = in.readLine();
                        accounts.put(newUser, Utils.md5(newPass));
                        saveAccounts();
                        out.println("Tạo user thành công.");
                        break;
                    case "2":
                        out.println("Mật khẩu mới:");
                        String pass = in.readLine();
                        accounts.put("admin", Utils.md5(pass));
                        saveAccounts();
                        out.println("Đã đổi mật khẩu.");
                        break;
                    case "3":
                        out.println("Tên user cần đổi:");
                        String u = in.readLine();
                        if (accounts.containsKey(u)) {
                            out.println("Mật khẩu mới:");
                            String newP = in.readLine();
                            accounts.put(u, Utils.md5(newP));
                            saveAccounts();
                            out.println("Đã đổi mật khẩu cho " + u);
                        } else {
                            out.println("Không tìm thấy user.");
                        }
                        break;
                    case "4":
                        zodiacFunction(in, out);
                        break;
                    case "5":
                        return;
                    default:
                        out.println("Lựa chọn không hợp lệ.");
                }
            }
        }

        private void handleUser(String username, BufferedReader in, PrintWriter out) throws IOException {
            while (true) {
                out.println("\n--- User Menu ---");
                out.println("1. Đổi mật khẩu");
                out.println("2. Xem cung hoàng đạo");
                out.println("3. Thoát");
                out.println("Chọn chức năng (1-3):");

                String choice = in.readLine();
                switch (choice) {
                    case "1":
                        out.println("Mật khẩu mới:");
                        String newPass = in.readLine();
                        accounts.put(username, Utils.md5(newPass));
                        saveAccounts();
                        out.println("Đã đổi mật khẩu.");
                        break;
                    case "2":
                        zodiacFunction(in, out);
                        break;
                    case "3":
                        return;
                    default:
                        out.println("Lựa chọn không hợp lệ.");
                }
            }
        }

        private void zodiacFunction(BufferedReader in, PrintWriter out) throws IOException {
            while (true) {
                try {
                    out.println("Nhập ngày sinh (1-31):");
                    int day = Integer.parseInt(in.readLine());
                    out.println("Nhập tháng sinh (1-12):");
                    int month = Integer.parseInt(in.readLine());

                    if (day < 1 || day > 31 || month < 1 || month > 12) {
                        out.println("Ngày hoặc tháng không hợp lệ. Vui lòng nhập lại.");
                        continue;
                    }

                    out.println("Cung hoàng đạo của bạn là: " + Utils.getZodiac(day, month));
                    break;

                } catch (NumberFormatException e) {
                    out.println("Định dạng không hợp lệ (phải là số). Bạn có muốn thử lại? (y/n):");
                    String retry = in.readLine();
                    if (!retry.equalsIgnoreCase("y")) {
                        break;
                    }
                }
            }
        }
    }
}
