package com.example.facebook_login;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FacebookLoginApplicationTests {

	@Test
	void contextLoads() {
	}

}
